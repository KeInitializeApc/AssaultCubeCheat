#pragma once
#include <iostream>
#include <Windows.h>


struct DataTypes
{
	DWORD PID;

	uint64_t OFFSET_HEALTH = 0x93EA64;
	uint64_t OFFSET_AMMO = 0x93EAB8;
	uint64_t OFFSET_PISTOL = 0x93EAA4;


	int OFFSET_HEALTHSET = 99999;
	int OFFSET_AMMOSET = 99999;
	int OFFSET_PISTOLAMMOSET = 99999;
}Data;
