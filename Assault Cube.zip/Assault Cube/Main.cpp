#include "Memory.h"

/*Credits

*	Discord: Network#1000

*	Program Used To Grab The Addresses > Cheat Engine 7.4 | https://www.cheatengine.org/
	
*	Getting The Base > https://stackoverflow.com/questions/14467229/get-base-address-of-process

*	Functions used to write the process memory :) > https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-writeprocessmemory

*/

int main()
{
	HWND WindowHandle = FindWindowA(0, ("AssaultCube"));

	GetWindowThreadProcessId(WindowHandle, &Data.PID);

	PVOID hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, Data.PID);

	while (main)
	{
		if (!WriteProcessMemory(hProcess, (LPVOID)Data.OFFSET_HEALTH, &Data.OFFSET_HEALTHSET, sizeof(Data.OFFSET_HEALTHSET), 0))
		{
			std::cout << ("Failed to Write Health!");
				return 1;
		}
		else if (!WriteProcessMemory(hProcess, (LPVOID)Data.OFFSET_AMMO, &Data.OFFSET_AMMOSET, sizeof(Data.OFFSET_AMMOSET), 0))
		{
			std::cout << ("Failed to LMG Ammo!");
			return 2;
		}
		else if (!WriteProcessMemory(hProcess, (LPVOID)Data.OFFSET_PISTOL, &Data.OFFSET_PISTOLAMMOSET, sizeof(Data.OFFSET_PISTOLAMMOSET), 0))
		{
			std::cout << ("Failed to Write Pistol Ammo!");
			return 3;
		}
		else
		{
			std::cout << ("Written Health > 99999 | Network#1000\n\n");
			std::cout << ("Written LMG Ammo > 99999 | Network#1000\n\n");
			std::cout << ("Written Pistol Ammo > 99999 | Network#1000\n\n");
		}
	}
}